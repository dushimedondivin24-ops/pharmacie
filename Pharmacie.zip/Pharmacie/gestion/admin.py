from django.contrib import admin
from .models import Categorie, Medicament, Client, Vente, DetailVente

admin.site.register(Categorie)
admin.site.register(Medicament)
admin.site.register(Client)
admin.site.register(Vente)
admin.site.register(DetailVente)

# Register your models here.
