from django.db import models

class Categorie(models.Model):
    nom = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    
    def __str__(self):
        return self.nom


class Medicament(models.Model):
    nom = models.CharField(max_length=150)
    categorie = models.ForeignKey(Categorie, on_delete=models.PROTECT, related_name="medicaments")
    prix_unitaire = models.DecimalField(max_digits=10, decimal_places=2)
    quantite_stock = models.PositiveIntegerField(default=0)

    def __str__(self):
        return self.nom


class Client(models.Model):
    nom = models.CharField(max_length=100)
    prenom = models.CharField(max_length=100)
    email = models.EmailField(max_length=20, blank=True, null=True)

    def __str__(self):
        return f"{self.prenom} {self.nom}"


class Vente(models.Model):
    client = models.ForeignKey(Client, on_delete=models.CASCADE, null=True, blank=True, related_name="ventes")
    date_vente = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Vente #{self.pk}"

class DetailVente(models.Model):
    vente = models.ForeignKey(Vente, on_delete=models.CASCADE, related_name="details")
    medicament = models.ForeignKey(Medicament, on_delete=models.PROTECT)
    quantite = models.PositiveIntegerField(default=1)
    prix_unitaire = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.medicament} x{self.quantite}"

# Create your models here.
