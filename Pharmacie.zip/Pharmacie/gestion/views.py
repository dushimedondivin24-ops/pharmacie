from django.shortcuts import render, redirect
from django.contrib.auth.mixins import LoginRequiredMixin #pour les classes
from django.contrib.auth.decorators import login_required #pour les fonctions
from django.contrib import messages
from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.db.models import Q # pour faire des recherches complexes

from .models import Categorie, Medicament, Client, Vente, DetailVente
from .forms import CategorieForm, MedicamentForm, ClientForm, VenteForm, DetailVenteFormSet


@login_required
def home(request):
    contexte = {
        'nb_medicaments': Medicament.objects.count(),
        'nb_clients': Client.objects.count(),
        'nb_ventes': Vente.objects.count(),
    }
    return render(request, 'gestion/home.html', contexte)


# ---------- CATEGORIE ----------
class CategorieListView(LoginRequiredMixin, ListView):
    model = Categorie
    template_name = 'gestion/categorie_list.html'
    context_object_name = 'categories'


class CategorieCreateView(LoginRequiredMixin, CreateView):
    model = Categorie
    form_class = CategorieForm
    template_name = 'gestion/form_generique.html'
    success_url = reverse_lazy('categorie_list')


class CategorieUpdateView(LoginRequiredMixin, UpdateView):
    model = Categorie
    form_class = CategorieForm
    template_name = 'gestion/form_generique.html'
    success_url = reverse_lazy('categorie_list')


class CategorieDeleteView(LoginRequiredMixin, DeleteView):
    model = Categorie
    template_name = 'gestion/confirm_delete.html'
    success_url = reverse_lazy('categorie_list')


# ---------- MEDICAMENT ----------
class MedicamentListView(LoginRequiredMixin, ListView):
    model = Medicament
    template_name = 'gestion/medicament_list.html'
    context_object_name = 'medicaments'

    def get_queryset(self):
        queryset = Medicament.objects.select_related('categorie').all()
        recherche = self.request.GET.get('q')
        if recherche:
            queryset = queryset.filter(
                Q(nom__icontains=recherche) | Q(categorie__nom__icontains=recherche)
            )
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['recherche'] = self.request.GET.get('q', '')
        return context


class MedicamentCreateView(LoginRequiredMixin, CreateView):
    model = Medicament
    form_class = MedicamentForm
    template_name = 'gestion/form_generique.html'
    success_url = reverse_lazy('medicament_list')


class MedicamentUpdateView(LoginRequiredMixin, UpdateView):
    model = Medicament
    form_class = MedicamentForm
    template_name = 'gestion/form_generique.html'
    success_url = reverse_lazy('medicament_list')


class MedicamentDeleteView(LoginRequiredMixin, DeleteView):
    model = Medicament
    template_name = 'gestion/confirm_delete.html'
    success_url = reverse_lazy('medicament_list')


# ---------- CLIENT ----------
class ClientListView(LoginRequiredMixin, ListView):
    model = Client
    template_name = 'gestion/client_list.html'
    context_object_name = 'clients'


class ClientCreateView(LoginRequiredMixin, CreateView):
    model = Client
    form_class = ClientForm
    template_name = 'gestion/form_generique.html'
    success_url = reverse_lazy('client_list')


class ClientUpdateView(LoginRequiredMixin, UpdateView):
    model = Client
    form_class = ClientForm
    template_name = 'gestion/form_generique.html'
    success_url = reverse_lazy('client_list')


class ClientDeleteView(LoginRequiredMixin, DeleteView):
    model = Client
    template_name = 'gestion/confirm_delete.html'
    success_url = reverse_lazy('client_list')


# ---------- VENTE ----------
class VenteListView(LoginRequiredMixin, ListView):
    model = Vente
    template_name = 'gestion/vente_list.html'
    context_object_name = 'ventes'


class VenteDetailView(LoginRequiredMixin, DetailView):
    model = Vente
    template_name = 'gestion/vente_detail.html'
    context_object_name = 'vente'


@login_required
def vente_create(request):
    vente_instance = Vente()
    if request.method == 'POST':
        form = VenteForm(request.POST)
        formset = DetailVenteFormSet(request.POST, instance=vente_instance)
        if form.is_valid() and formset.is_valid():
            vente = form.save(commit=False)
            vente.save()
            formset.instance = vente
            formset.save()
            for detail in vente.details.all():
                med = detail.medicament
                med.quantite_stock = max(0, med.quantite_stock - detail.quantite)
                med.save()
            messages.success(request, "Vente enregistrée avec succès.")
            return redirect('vente_detail', pk=vente.pk)
    else:
        form = VenteForm()
        formset = DetailVenteFormSet(instance=vente_instance)
    return render(request, 'gestion/vente_form.html', {'form': form, 'formset': formset})


class VenteDeleteView(LoginRequiredMixin, DeleteView):
    model = Vente
    template_name = 'gestion/confirm_delete.html'
    success_url = reverse_lazy('vente_list')
# Create your views here.
