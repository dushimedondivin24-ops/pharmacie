from django import forms
from .models import Categorie, Medicament, Client, Vente, DetailVente


class CategorieForm(forms.ModelForm):
    class Meta:
        model = Categorie
        fields = ['nom', 'description']
        widgets = {
            'nom': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }


class MedicamentForm(forms.ModelForm):
    class Meta:
        model = Medicament
        fields = ['nom', 'categorie', 'prix_unitaire', 'quantite_stock']
        widgets = {
            'nom': forms.TextInput(attrs={'class': 'form-control'}),
            'categorie': forms.Select(attrs={'class': 'form-select'}),
            'prix_unitaire': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
            'quantite_stock': forms.NumberInput(attrs={'class': 'form-control'}),
        }


class ClientForm(forms.ModelForm):
    class Meta:
        model = Client
        fields = ['nom', 'prenom', 'email']
        widgets = {
            'nom': forms.TextInput(attrs={'class': 'form-control'}),
            'prenom': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
        }


class VenteForm(forms.ModelForm):
    class Meta:
        model = Vente
        fields = ['client']
        widgets = {
            'client': forms.Select(attrs={'class': 'form-select'}),
        }


class DetailVenteForm(forms.ModelForm):
    class Meta:
        model = DetailVente
        fields = ['medicament', 'quantite', 'prix_unitaire']
        widgets = {
            'medicament': forms.Select(attrs={'class': 'form-select'}),
            'quantite': forms.NumberInput(attrs={'class': 'form-control', 'min': 1}),
            'prix_unitaire': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
        }


DetailVenteFormSet = forms.inlineformset_factory(
    Vente, DetailVente, form=DetailVenteForm, extra=1, can_delete=True
)