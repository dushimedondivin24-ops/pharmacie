from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),

    path('categories/', views.CategorieListView.as_view(), name='categorie_list'),
    path('categories/ajouter/', views.CategorieCreateView.as_view(), name='categorie_create'),
    path('categories/<int:pk>/modifier/', views.CategorieUpdateView.as_view(), name='categorie_update'),
    path('categories/<int:pk>/supprimer/', views.CategorieDeleteView.as_view(), name='categorie_delete'),

    path('medicaments/', views.MedicamentListView.as_view(), name='medicament_list'),
    path('medicaments/ajouter/', views.MedicamentCreateView.as_view(), name='medicament_create'),
    path('medicaments/<int:pk>/modifier/', views.MedicamentUpdateView.as_view(), name='medicament_update'),
    path('medicaments/<int:pk>/supprimer/', views.MedicamentDeleteView.as_view(), name='medicament_delete'),

    path('clients/', views.ClientListView.as_view(), name='client_list'),
    path('clients/ajouter/', views.ClientCreateView.as_view(), name='client_create'),
    path('clients/<int:pk>/modifier/', views.ClientUpdateView.as_view(), name='client_update'),
    path('clients/<int:pk>/supprimer/', views.ClientDeleteView.as_view(), name='client_delete'),

    path('ventes/', views.VenteListView.as_view(), name='vente_list'),
    path('ventes/<int:pk>/', views.VenteDetailView.as_view(), name='vente_detail'),
    path('ventes/ajouter/', views.vente_create, name='vente_create'),
    path('ventes/<int:pk>/supprimer/', views.VenteDeleteView.as_view(), name='vente_delete'),
]